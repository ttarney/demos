﻿using System;

namespace Corteva.IO.ImageryServices.ContentNegotiation
{
    public class Class1
    {
    }
}
